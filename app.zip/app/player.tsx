import { Colors } from "@/constants/theme";
import { supabase } from "@/supabaseConfig";
import { Ionicons } from "@expo/vector-icons";
import Slider from "@react-native-community/slider";
import * as FileSystem from "expo-file-system/legacy"; // <--- ADD THIS
import { useRouter } from "expo-router";
import React, { useEffect, useState } from "react";

import {
  ActivityIndicator,
  Alert,
  Dimensions,
  Image,
  ImageBackground,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { usePlayer } from "./PlayerContext";

const { width, height } = Dimensions.get("window");

export default function PlayerScreen() {
  const router = useRouter();

  // 🟢 STATE: Track download status
  const [isDownloaded, setIsDownloaded] = useState(false);

  // Helper: Get consistent filename
  const getLocalPath = (title: string) => {
    return FileSystem.documentDirectory + title.replace(/\s+/g, "_") + ".mp3";
  };

  // 1. ROBUST CHECK: Runs whenever the song changes
  useEffect(() => {
    let isCurrent = true;

    const checkStatus = async () => {
      if (!currentTrack) {
        setIsDownloaded(false);
        return;
      }

      // 1. Force Reset Visuals First
      setIsDownloaded(false);

      try {
        const fileUri = getLocalPath(currentTrack.title);
        const info = await FileSystem.getInfoAsync(fileUri);

        // 2. Only update if component is still mounted & song hasn't changed
        if (isCurrent) {
          if (info.exists) {
            setIsDownloaded(true);
          } else {
            setIsDownloaded(false); // Explicitly ensure it stays false
          }
        }
      } catch (e) {
        console.log("Error checking file", e);
      }
    };

    checkStatus();

    return () => {
      isCurrent = false;
    };
  }, [currentTrack]); // <--- CHANGED: Fires on ANY track object change

  // 📥 NEW DOWNLOAD LOGIC (Fixes Deprecation)
  const downloadTrack = async () => {
    if (!currentTrack) return;

    // 🔓 FIX: Allow download if user is Premium OR track is unlocked
    if (currentTrack.is_locked && !isPremium) {
      Alert.alert("Premium Only", "Subscribe to download this track.");
      return;
    }

    try {
      // 1. Get consistent path
      const fileUri = getLocalPath(currentTrack.title);

      Alert.alert("Downloading...", "Saving to your library.");

      const downloadResumable = FileSystem.createDownloadResumable(
        currentTrack.url,
        fileUri,
        {},
        (downloadProgress) => {
          console.log(
            downloadProgress.totalBytesWritten /
              downloadProgress.totalBytesExpectedToWrite,
          );
        },
      );

      // 2. Wait for finish
      await downloadResumable.downloadAsync();

      // 3. 🟢 FLIP ICON FIRST, THEN ALERT
      setIsDownloaded(true);

      // Small delay to ensure UI renders before Alert freezes it
      setTimeout(() => {
        Alert.alert("Success ✅", "Saved offline!");
      }, 100);
    } catch (e) {
      console.error(e);
      Alert.alert("Error", "Download failed.");
    }
  };

  // 1. GET DATA FROM GLOBAL CONTEXT (Your logic preserved)
  const {
    currentTrack,
    isPlaying,
    duration,
    position,
    togglePlayPause,
    playNext,
    playPrev,
    seekTo,
    isBuffering,
    queue,
    currentIndex,
    isPremium, // <--- Get the status
  } = usePlayer();

  // --- FAVORITES LOGIC ---
  const [isLiked, setIsLiked] = useState(false);

  useEffect(() => {
    checkLikeStatus();
  }, [currentTrack]);

  async function checkLikeStatus() {
    if (!currentTrack) return;
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from("favorites")
      .select("*")
      .eq("user_id", user.id)
      .eq("song_id", currentTrack.id)
      .single();

    setIsLiked(!!data);
  }

  async function toggleLike() {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user || !currentTrack) return;

    if (isLiked) {
      // Unlike
      await supabase
        .from("favorites")
        .delete()
        .eq("user_id", user.id)
        .eq("song_id", currentTrack.id);
      setIsLiked(false);
    } else {
      // Like
      await supabase
        .from("favorites")
        .insert({ user_id: user.id, song_id: currentTrack.id });
      setIsLiked(true);
    }
  }

  // 2. Format Time Helper
  const formatTime = (millis) => {
    if (!millis) return "0:00";
    const minutes = Math.floor(millis / 60000);
    const seconds = Math.floor((millis % 60000) / 1000);
    return `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
  };

  // 3. Loading State
  if (!currentTrack) {
    return (
      <View style={[styles.container, styles.center]}>
        <ActivityIndicator size="large" color={Colors.premium.gold} />
        <Text style={styles.loadingText}>Loading Track...</Text>
      </View>
    );
  }

  // 4. PREMIUM RENDER
  return (
    <View style={styles.container}>
      {/* BACKGROUND: Blurred Album Art */}
      <ImageBackground
        source={{
          uri: currentTrack.artwork || "https://via.placeholder.com/400",
        }}
        style={styles.backgroundImage}
        blurRadius={40} // The "Frosted Glass" effect
      >
        {/* Dark Overlay for readability */}
        <View style={styles.overlay}>
          {/* HEADER */}
          <View style={styles.header}>
            <TouchableOpacity
              onPress={() => router.back()}
              style={styles.iconButton}
            >
              <Ionicons name="chevron-down" size={28} color="white" />
            </TouchableOpacity>
            <Text style={styles.headerTitle}>NOW PLAYING</Text>
            <TouchableOpacity style={styles.iconButton}>
              <Ionicons name="ellipsis-horizontal" size={24} color="white" />
            </TouchableOpacity>
          </View>

          {/* ALBUM ART (Floating Card) */}
          <View style={styles.artContainer}>
            <View style={styles.artWrapper}>
              {currentTrack.artwork ? (
                <Image
                  source={{ uri: currentTrack.artwork }}
                  style={styles.hdAlbumArt}
                />
              ) : (
                <View style={[styles.hdAlbumArt, styles.placeholderArt]}>
                  <Ionicons name="musical-notes" size={80} color="#555" />
                </View>
              )}
            </View>
          </View>

          {/* TRACK INFO (With Heart) */}
          <View style={styles.infoContainer}>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
                width: "100%",
                paddingHorizontal: 30,
              }}
            >
              {/* Text Area */}
              <View style={{ flex: 1, marginRight: 10 }}>
                <Text
                  style={[styles.title, { textAlign: "left" }]}
                  numberOfLines={1}
                >
                  {currentTrack.title}
                </Text>
                <Text style={[styles.artist, { textAlign: "left" }]}>
                  {currentTrack.artist || "Motivation App"}
                </Text>
              </View>

              {/* Download Button (Smart Icon) */}
              <TouchableOpacity
                onPress={
                  isDownloaded
                    ? () => Alert.alert("Library", "Already downloaded! ✅")
                    : downloadTrack
                }
                style={{ marginRight: 20 }}
              >
                <Ionicons
                  name={
                    isDownloaded ? "checkmark-circle" : "cloud-download-outline"
                  }
                  size={28}
                  color={isDownloaded ? "#4ADE80" : "#FFF"} // Green if downloaded, White if not
                />
              </TouchableOpacity>

              {/* Heart Button */}
              <TouchableOpacity onPress={toggleLike}>
                <Ionicons
                  name={isLiked ? "heart" : "heart-outline"}
                  size={28}
                  color={isLiked ? Colors.premium.gold : "#FFF"}
                />
              </TouchableOpacity>
            </View>
          </View>

          {/* PROGRESS SLIDER */}
          <View style={styles.progressContainer}>
            <Slider
              style={{ width: "100%", height: 40 }}
              minimumValue={0}
              maximumValue={duration}
              value={position}
              onSlidingComplete={seekTo}
              minimumTrackTintColor={Colors.premium.gold}
              maximumTrackTintColor="rgba(255,255,255,0.3)"
              thumbTintColor={Colors.premium.gold}
            />
            <View style={styles.timeLabels}>
              <Text style={styles.timeText}>{formatTime(position)}</Text>
              <Text style={styles.timeText}>{formatTime(duration)}</Text>
            </View>
          </View>

          {/* CONTROLS */}
          <View style={styles.controls}>
            {/* Prev */}
            <TouchableOpacity onPress={playPrev} disabled={currentIndex === 0}>
              <Ionicons
                name="play-skip-back"
                size={35}
                color={currentIndex === 0 ? "rgba(255,255,255,0.2)" : "white"}
              />
            </TouchableOpacity>

            {/* Play/Pause (Big Gold Button) */}
            <TouchableOpacity
              onPress={togglePlayPause}
              style={styles.playButton}
            >
              {isBuffering ? (
                <ActivityIndicator color="black" size="small" />
              ) : (
                <Ionicons
                  name={isPlaying ? "pause" : "play"}
                  size={32}
                  color="black"
                  style={{ marginLeft: isPlaying ? 0 : 4 }}
                />
              )}
            </TouchableOpacity>

            {/* Next */}
            <TouchableOpacity
              onPress={playNext}
              disabled={!queue || currentIndex >= queue.length - 1}
            >
              <Ionicons
                name="play-skip-forward"
                size={35}
                color={
                  !queue || currentIndex >= queue.length - 1
                    ? "rgba(255,255,255,0.2)"
                    : "white"
                }
              />
            </TouchableOpacity>
          </View>

          {/* Bottom Spacer */}
          <View style={{ height: 40 }} />
        </View>
      </ImageBackground>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#000" },
  center: { justifyContent: "center", alignItems: "center" },
  loadingText: { color: "white", marginTop: 20 },

  backgroundImage: { flex: 1, width: "100%", height: "100%" },
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.6)",
    paddingHorizontal: 20,
  },

  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 60,
  },
  iconButton: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.1)",
    borderRadius: 20,
  },
  headerTitle: {
    color: "white",
    fontSize: 12,
    fontWeight: "700",
    letterSpacing: 2,
  },

  artContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginVertical: 30,
  },
  artWrapper: {
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 20 },
    shadowOpacity: 0.6,
    shadowRadius: 30,
    elevation: 25,
  },
  hdAlbumArt: {
    width: width * 0.8,
    height: width * 0.8,
    borderRadius: 25,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.1)",
  },
  placeholderArt: {
    backgroundColor: "#333",
    justifyContent: "center",
    alignItems: "center",
  },

  infoContainer: { alignItems: "center", marginBottom: 30 },
  title: {
    color: "white",
    fontSize: 24,
    fontWeight: "800",
    textAlign: "center",
    marginBottom: 8,
    paddingHorizontal: 10,
  },
  artist: { color: "#AAA", fontSize: 16, fontWeight: "600" },

  progressContainer: { width: "100%", marginBottom: 40 },
  timeLabels: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 5,
  },
  timeText: { color: "#CCC", fontSize: 12, fontWeight: "600" },

  controls: {
    flexDirection: "row",
    justifyContent: "space-evenly",
    alignItems: "center",
    marginBottom: 40,
    width: "100%",
  },
  playButton: {
    backgroundColor: Colors.premium.gold,
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: Colors.premium.gold,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 20,
    elevation: 10,
  },
});
