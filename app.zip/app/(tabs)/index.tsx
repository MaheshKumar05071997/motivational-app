import { Colors } from "@/constants/theme"; // Your premium colors
import { useColorScheme } from "@/hooks/use-color-scheme"; // Theme support
import { Ionicons } from "@expo/vector-icons"; // Premium icons
import { BlurView } from "expo-blur"; // Glass effect
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Dimensions,
  SafeAreaView, // <--- Added
  ScrollView,
  Share,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import Animated, { FadeInDown } from "react-native-reanimated"; // Smooth entry
import { supabase } from "../../supabaseConfig";
export default function HomeScreen() {
  // 🟢 SHARE LOGIC
  const shareQuote = async () => {
    try {
      await Share.share({
        message:
          "“Soch Badlo, Jeevan Badlo” - Download the Motivational App today! 🚀",
      });
    } catch (error) {
      console.log(error);
    }
  };
  const router = useRouter();
  const theme = useColorScheme() ?? "dark"; // Detects Light or Dark mode
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCategories();
  }, []);

  async function fetchCategories() {
    try {
      setLoading(true);
      let { data, error } = await supabase.from("categories").select("*");

      if (error) {
        console.error("Error fetching data:", error);
      } else {
        setCategories(data);
      }
    } catch (err) {
      console.error("Unexpected error:", err);
    } finally {
      setLoading(false);
    }
  }

  // Helper to get the right emoji
  const getIcon = (iconName) => {
    switch (iconName) {
      case "dumbbell":
        return "💪";
      case "brain":
        return "🧠";
      case "moon":
        return "🌙";
      default:
        return "🎵";
    }
  };

  const { width } = Dimensions.get("window");
  const cardWidth = width / 2 - 30; // Calculate grid size

  return (
    <View style={styles.container}>
      {/* Background removed to show Live Wallpaper */}

      <SafeAreaView style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ paddingBottom: 100 }}>
          {/* 2. Header & Daily Quote Section */}
          <View style={styles.header}>
            <Text style={styles.greeting}>GOOD MORNING, MUKESH</Text>

            <Animated.View
              entering={FadeInDown.duration(1000).springify()}
              style={styles.quoteContainer}
            >
              <BlurView intensity={40} tint="light" style={styles.quoteCard}>
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "flex-start", // Aligns text to top
                    gap: 15, // <--- Adds space between Text and Share Icon
                  }}
                >
                  <View style={{ flex: 1 }}>
                    <Text style={styles.quoteTitle}>✨ Aaj ka Vichar</Text>
                    <Text style={styles.quoteText}>
                      “Life is not about finding yourself. Life is about
                      creating yourself.”
                    </Text>
                  </View>

                  {/* Share Button */}
                  <TouchableOpacity onPress={shareQuote} style={{ padding: 5 }}>
                    <Ionicons
                      name="share-social-outline"
                      size={24}
                      color="#fff"
                    />
                  </TouchableOpacity>
                </View>
              </BlurView>
            </Animated.View>
          </View>

          {/* 3. The Cinematic Grid */}
          <View style={styles.content}>
            <Text style={styles.sectionTitle}>EXPLORE ZONES</Text>

            {loading ? (
              <ActivityIndicator
                size="large"
                color={Colors.premium.gold}
                style={{ marginTop: 50 }}
              />
            ) : (
              <View style={styles.gridContainer}>
                {categories.map((item, index) => (
                  <Animated.View
                    key={item.id}
                    entering={FadeInDown.delay(index * 100).springify()}
                    style={{ width: cardWidth, marginBottom: 20 }}
                  >
                    <TouchableOpacity
                      onPress={() =>
                        router.push({
                          pathname: "/playlist",
                          params: {
                            categoryId: item.id,
                            categoryName: item.name,
                          },
                        })
                      }
                      activeOpacity={0.8}
                      style={styles.posterCard}
                    >
                      <LinearGradient
                        colors={[
                          "rgba(255,255,255,0.1)",
                          "rgba(255,255,255,0.02)",
                        ]}
                        style={StyleSheet.absoluteFill}
                      />

                      {/* Icon */}
                      <View style={styles.iconContainer}>
                        <Ionicons
                          name={item.icon || "star"}
                          size={32}
                          color="#fff"
                        />
                      </View>

                      {/* Text Bottom */}
                      <View style={styles.cardTextContainer}>
                        <Text style={styles.cardTitle}>{item.name}</Text>
                        <Text style={styles.cardSubtitle}>Listen Now</Text>
                      </View>
                    </TouchableOpacity>
                  </Animated.View>
                ))}
              </View>
            )}
          </View>
        </ScrollView>
      </SafeAreaView>
      <StatusBar barStyle="light-content" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "transparent" },

  header: { paddingHorizontal: 20, paddingTop: 20, marginBottom: 30 },
  greeting: {
    color: "#A1A1AA",
    fontSize: 12,
    letterSpacing: 2,
    fontWeight: "700",
    marginBottom: 15,
    textTransform: "uppercase",
  },

  // Quote Card Styles
  quoteContainer: { borderRadius: 20, overflow: "hidden", marginTop: 10 },
  quoteGlass: { padding: 25, backgroundColor: "rgba(255,255,255,0.05)" },
  quoteIcon: { marginBottom: 15, opacity: 0.8 },
  quoteText: {
    color: "#fff",
    fontSize: 24,
    fontWeight: "300",
    lineHeight: 34,
    fontStyle: "italic",
  },
  quoteAuthor: {
    color: Colors.premium.gold,
    fontSize: 14,
    fontWeight: "700",
    marginTop: 15,
    textAlign: "right",
  },

  content: { paddingHorizontal: 20 },
  sectionTitle: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
    marginBottom: 20,
    letterSpacing: 1,
  },

  // Grid Styles
  gridContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },

  posterCard: {
    height: 180,
    borderRadius: 20,
    overflow: "hidden",
    backgroundColor: "#1A1A1A",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.1)",
    justifyContent: "space-between",
    padding: 15,
  },
  iconContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: "rgba(255,255,255,0.1)",
    justifyContent: "center",
    alignItems: "center",
  },
  cardTextContainer: {},
  cardTitle: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
    marginBottom: 5,
  },
  cardSubtitle: { color: "#888", fontSize: 12, fontWeight: "500" },
});
