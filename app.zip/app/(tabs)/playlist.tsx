import { Colors } from "@/constants/theme";
import { supabase } from "@/supabaseConfig";
import { Ionicons } from "@expo/vector-icons";
import { BlurView } from "expo-blur";
import { useFocusEffect, useLocalSearchParams, useRouter } from "expo-router";
import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import Animated, { FadeInDown, FadeInUp } from "react-native-reanimated";
import { usePlayer } from "../PlayerContext";

export default function PlaylistScreen() {
  const { categoryId, categoryName } = useLocalSearchParams();
  const router = useRouter();
  const [tracks, setTracks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isPremium, setIsPremium] = useState(false);

  const { playTrackList, currentTrack, isPlaying } = usePlayer();

  useFocusEffect(
    useCallback(() => {
      checkUserStatus();
    }, []),
  );

  useEffect(() => {
    if (categoryId) {
      setTracks([]); // <--- CLEAR OLD SONGS
      setLoading(true);
      fetchTracks();
    }
  }, [categoryId]);

  async function checkUserStatus() {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (user) {
      const { data } = await supabase
        .from("profiles")
        .select("is_premium")
        .eq("id", user.id)
        .single();
      if (data) setIsPremium(data.is_premium);
    }
  }

  async function fetchTracks() {
    try {
      // FIX 1: specific table name "audios" instead of "songs"
      if (!categoryId) return;

      let { data, error } = await supabase
        .from("audios")
        .select("*")
        .eq("category_id", categoryId) // <--- STRICT FILTER
        .order("created_at", { ascending: true });

      if (error) {
        console.error("Supabase Error:", error);
      } else {
        setTracks(data || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  const handlePlayTrack = (track, index) => {
    // 1. Check if locked
    if (track.is_locked && !isPremium) {
      Alert.alert(
        "Locked Track 🔒",
        "Upgrade to Premium to unlock this exclusive content!",
        [
          { text: "Cancel", style: "cancel" },
          { text: "Upgrade", onPress: () => router.push("/paywall") },
        ],
      );
      return;
    }

    // 2. THE FIX: Convert "audio_url" (Database Name) to "url" (Player Name)
    const formattedTracks = tracks.map((t) => ({
      id: t.id,
      url: t.audio_url, // <--- THIS MAPS IT CORRECTLY
      title: t.title,
      artist: "Motivation", // Default artist since DB doesn't have one yet
      artwork: t.image_url, // Maps image_url to artwork
      duration: t.duration_sec,
      is_locked: t.is_locked, // <--- ADD THIS LINE!
    }));

    // 3. Play the formatted list
    playTrackList(formattedTracks, index);
    router.push("/player");
  };

  return (
    <View style={styles.container}>
      {/* Gradient DELETED for video */}

      <Animated.View
        entering={FadeInUp.duration(800).springify()}
        style={styles.header}
      >
        <TouchableOpacity
          onPress={() => router.back()}
          style={styles.backButton}
        >
          <Ionicons name="arrow-back" size={24} color="#fff" />
        </TouchableOpacity>

        <View style={styles.headerContent}>
          <Text style={styles.categoryLabel}>SELECTED VIBE</Text>
          <Text style={styles.title}>{categoryName || "Playlist"}</Text>
          <View style={styles.metaBadge}>
            <Ionicons name="musical-notes" size={12} color="#000" />
            <Text style={styles.metaText}>{tracks.length} Tracks</Text>
          </View>
        </View>
      </Animated.View>

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color={Colors.premium.gold} />
        </View>
      ) : (
        <FlatList
          data={tracks}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.listContent}
          renderItem={({ item, index }) => {
            const isActive = currentTrack && currentTrack.id === item.id;

            return (
              <Animated.View
                entering={FadeInDown.delay(index * 100)
                  .duration(600)
                  .springify()}
              >
                <TouchableOpacity
                  onPress={() => handlePlayTrack(item, index)}
                  activeOpacity={0.7}
                >
                  <BlurView
                    intensity={isActive ? 40 : 10}
                    tint="dark"
                    style={[styles.trackRow, isActive && styles.activeTrackRow]}
                  >
                    <View style={styles.trackIndex}>
                      {isActive && isPlaying ? (
                        <Ionicons
                          name="pulse"
                          size={18}
                          color={Colors.premium.gold}
                        />
                      ) : (
                        <Text
                          style={[
                            styles.indexText,
                            isActive && { color: Colors.premium.gold },
                          ]}
                        >
                          {index + 1}
                        </Text>
                      )}
                    </View>

                    <View style={styles.trackInfo}>
                      <Text
                        style={[
                          styles.trackTitle,
                          isActive && { color: Colors.premium.gold },
                        ]}
                        numberOfLines={1}
                      >
                        {item.title}
                      </Text>
                      {/* Fixed: DB column is duration_sec */}
                      <Text style={styles.durationText}>
                        {Math.floor((item.duration_sec || 0) / 60)}:
                        {((item.duration_sec || 0) % 60)
                          .toString()
                          .padStart(2, "0")}{" "}
                        mins
                      </Text>
                    </View>

                    {item.is_locked && !isPremium ? (
                      <Ionicons name="lock-closed" size={20} color="#FF4500" />
                    ) : (
                      <View
                        style={[
                          styles.playButton,
                          isActive && { backgroundColor: Colors.premium.gold },
                        ]}
                      >
                        <Ionicons
                          name={isActive ? "pause" : "play"}
                          size={14}
                          color={isActive ? "#000" : "#fff"}
                          style={{ marginLeft: isActive ? 0 : 2 }}
                        />
                      </View>
                    )}
                  </BlurView>
                </TouchableOpacity>
              </Animated.View>
            );
          }}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "transparent" }, // <--- Changed to transparent
  center: { flex: 1, justifyContent: "center", alignItems: "center" },

  header: {
    paddingTop: 60,
    paddingHorizontal: 25,
    paddingBottom: 30,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "rgba(255,255,255,0.1)",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 20,
  },
  headerContent: { alignItems: "flex-start" },
  categoryLabel: {
    color: Colors.premium.gold,
    fontSize: 12,
    fontWeight: "700",
    letterSpacing: 2,
    marginBottom: 5,
    textTransform: "uppercase",
  },
  title: {
    fontSize: 32,
    fontWeight: "800",
    color: "#fff",
    letterSpacing: -0.5,
    marginBottom: 15,
  },
  metaBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: Colors.premium.gold,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  metaText: { fontSize: 12, fontWeight: "700", color: "#000" },

  listContent: { paddingHorizontal: 20, paddingBottom: 100 },

  trackRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
    borderRadius: 16,
    padding: 15,
    overflow: "hidden",
    backgroundColor: "rgba(0,0,0,0.5)", // Darker for white text
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.05)",
  },
  activeTrackRow: {
    borderColor: Colors.premium.gold,
    backgroundColor: "rgba(212, 175, 55, 0.1)",
  },

  trackIndex: {
    width: 30,
    alignItems: "center",
    marginRight: 10,
  },
  indexText: { color: "#666", fontWeight: "700", fontSize: 14 },

  trackInfo: { flex: 1 },
  trackTitle: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
    marginBottom: 2,
  },
  durationText: { color: "#888", fontSize: 12 },

  playButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: "rgba(255,255,255,0.1)",
    justifyContent: "center",
    alignItems: "center",
  },
});
