import { Colors } from "@/constants/theme";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient"; // <--- For Gold Card
import * as Notifications from "expo-notifications";
import { useFocusEffect, useRouter } from "expo-router";
import React, { useCallback, useState } from "react";
import {
  Alert,
  ScrollView,
  StyleSheet,
  Switch,
  Text, // <--- Added for Edit Name
  TextInput, // <--- ADD
  TouchableOpacity,
  View,
  animatedBreath,
} from "react-native";
import Animated, { FadeInDown } from "react-native-reanimated";
import { usePlayer } from "../../app/PlayerContext";
import { supabase } from "../../supabaseConfig";

export default function ProfileScreen() {
  const router = useRouter();
  const [displayName, setDisplayName] = useState("Loading...");
  const [userEmail, setUserEmail] = useState("");
  const [isPremium, setIsPremium] = useState(false);

  // RESTORED: Your original stats state
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    streak: 0,
    minutes: 0,
    points: 0, // <--- NEW SEPARATE STAT
    level: "Novice",
  }); // Gamification State

  const [favorites, setFavorites] = useState([]); // <--- NEW STATE
  const { playTrackList } = usePlayer(); // <--- NEW HOOK
  // Edit Name State
  const [isEditing, setIsEditing] = useState(false);
  const [newName, setNewName] = useState("");

  // Fetch Favorites Wrapper
  async function getFavorites() {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from("favorites")
      .select("audios(*)")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false }) // Recent first
      .limit(3); // <--- ONLY TOP 3

    if (data) {
      // Flatten the response (Supabase returns { audios: {...} })
      const songs = data.map((item) => item.audios).filter(Boolean);
      setFavorites(songs);
    }
  }

  // RESTORED: Your exact logic to fetch data
  useFocusEffect(
    useCallback(() => {
      getProfile();
      getFavorites(); // <--- CALL THIS TOO
    }, []),
  );

  async function getProfile() {
    try {
      setLoading(true);

      // 1. Get the current User from Supabase Auth
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) return; // <--- ADDS SAFETY CHECK

      // 2. Set Basic Info
      setUserEmail(user?.email || "");

      // 3. Fetch Real Data
      const { data } = await supabase
        .from("profiles")
        .select(`full_name, streak_count, total_minutes, points`)
        .eq("id", user.id)
        .single();

      // FIX: Prefer Database Name -> then Email -> then "Soul"
      if (data) {
        setDisplayName(data.full_name || user.email?.split("@")[0] || "Soul");
        // ... rest of stats logic
      }

      if (data) {
        // 4. Calculate Level dynamically based on REAL database minutes
        const mins = data.total_minutes || 0;
        let currentLevel = "Sadhak (Novice)";
        if (mins > 100) currentLevel = "Yogi (Seeker)";
        if (mins > 500) currentLevel = "Rishi (Master)";

        // 5. Update the UI with Database values
        setStats({
          streak: data.streak_count || 0,
          minutes: mins,
          points: data.points || 0, // <--- SET POINTS
          level: currentLevel,
        });
      }
    } catch (error) {
      if (error instanceof Error) {
        console.log("Profile Error:", error.message);
      }
    } finally {
      setLoading(false);
    }
  }

  async function testNotification() {
    try {
      await Notifications.scheduleNotificationAsync({
        content: {
          title: "🔔 Test Notification",
          body: "Boom! Your notifications are working perfectly.",
          sound: true,
        },
        trigger: {
          seconds: 2,
          channelId: "default", // <--- REQUIRED for Android
        } as any,
      });
      Alert.alert("Success", "Wait 2 seconds...");
    } catch (error) {
      // Graceful fallback for Expo Go limitations
      Alert.alert(
        "Notice",
        "Notifications may not work in Expo Go on Android (SDK 53). They will work in the final built app.",
      );
      console.log(error);
    }
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    router.replace("/auth");
  }

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.content}>
        {/* 1. ANIMATED HEADER */}
        <Animated.View
          entering={FadeInDown.duration(800)}
          style={styles.header}
        >
          <Animated.View style={[styles.avatarRing, animatedBreath]}>
            <LinearGradient
              colors={[Colors.premium.gold, "#B8860B"]}
              style={{ borderRadius: 100, padding: 3 }}
            >
              <View style={styles.avatarContainer}>
                <Ionicons name="person" size={50} color="#fff" />
              </View>
            </LinearGradient>
          </Animated.View>

          {/* EDIT NAME INPUT */}
          {isEditing ? (
            <View style={styles.editContainer}>
              <TextInput
                style={styles.editInput}
                value={newName}
                onChangeText={setNewName}
                autoFocus={true}
                placeholder="Enter Name"
                placeholderTextColor="#666"
              />
              <TouchableOpacity onPress={saveName} style={styles.saveBtn}>
                <Ionicons
                  name="checkmark-circle"
                  size={30}
                  color={Colors.premium.gold}
                />
              </TouchableOpacity>
            </View>
          ) : (
            <TouchableOpacity
              onPress={() => {
                setNewName(displayName);
                setIsEditing(true);
              }}
            >
              <Text style={styles.username}>{displayName}</Text>
              <Text style={styles.editHint}>Tap to edit identity</Text>
            </TouchableOpacity>
          )}
        </Animated.View>

        {/* 2. THE GOLDEN KARMA CARD (Points Display) */}
        {/* 2. THE GOLDEN KARMA CARD (Points Display) */}
        <Animated.View entering={FadeInDown.delay(200).springify()}>
          <LinearGradient
            colors={[Colors.premium.gold, "#FFD700", "#B8860B"]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.pointsCard}
          >
            <View>
              <Text style={styles.pointsLabel}>KARMA POINTS</Text>
              <Text style={styles.pointsValue}>{stats.points}</Text>
              <Text style={styles.pointsSub}>Level: {stats.level}</Text>
            </View>
            <View style={styles.iconCircle}>
              <Ionicons name="sparkles" size={32} color="#4a4008" />
            </View>
          </LinearGradient>
        </Animated.View>

        {/* 3. GAMIFIED SPIRITUAL PATH (Cartoon Style) */}
        <Text style={styles.sectionTitle}>Your Journey</Text>

        <View style={styles.pathContainer}>
          {/* LEVEL 1: SADHAK (Unlocked by Default) */}
          <LevelNode
            level="Sadhak"
            desc="The Beginning"
            minutes={stats.minutes}
            required={0}
            isLast={false}
          />

          {/* LEVEL 2: YOGI (Unlock at 100 mins) */}
          <LevelNode
            level="Yogi"
            desc="The Seeker"
            minutes={stats.minutes}
            required={100}
            isLast={false}
          />

          {/* LEVEL 3: RISHI (Unlock at 500 mins) */}
          <LevelNode
            level="Rishi"
            desc="The Master"
            minutes={stats.minutes}
            required={500}
            isLast={true}
          />
        </View>

        {/* Helper Badge */}
        <View style={styles.helperBadge}>
          <Ionicons
            name="information-circle"
            size={20}
            color={Colors.premium.gold}
          />
          <Text style={styles.helperText}>
            Unlock levels to reveal new avatars & powers.
          </Text>
        </View>
        {/* 4. SETTINGS LIST */}
        <Text style={styles.sectionTitle}>Preferences</Text>

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => router.push("/paywall")}
        >
          <View style={styles.menuLeft}>
            <Ionicons name="diamond" size={22} color={Colors.premium.gold} />
            <Text style={[styles.menuText, { color: Colors.premium.gold }]}>
              Premium Plan
            </Text>
          </View>
          <Ionicons
            name="chevron-forward"
            size={18}
            color={Colors.premium.gold}
          />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => router.push("/downloads")}
        >
          <View style={styles.menuLeft}>
            <Ionicons name="cloud-download-outline" size={22} color="#fff" />
            <Text style={styles.menuText}>My Downloads</Text>
          </View>
          <Ionicons name="chevron-forward" size={18} color="#666" />
        </TouchableOpacity>

        <View style={styles.menuItem}>
          <View style={styles.menuLeft}>
            <Ionicons name="notifications-outline" size={22} color="#fff" />
            <Text style={styles.menuText}>Daily Reminders</Text>
          </View>
          <Switch
            value={true}
            trackColor={{ false: "#333", true: Colors.premium.gold }}
            thumbColor={"#fff"}
          />
        </View>

        <TouchableOpacity onPress={handleLogout} style={styles.logoutBtn}>
          <Text style={styles.logoutText}>DISCONNECT SOUL (LOGOUT)</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );

  async function saveName() {
    if (!newName.trim()) {
      setIsEditing(false);
      return;
    }
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (user) {
        await supabase
          .from("profiles")
          .update({ full_name: newName })
          .eq("id", user.id);
        setIsEditing(false);
        getProfile(); // Refresh UI
        Alert.alert("Updated", "Your spiritual name has been changed.");
      }
    } catch (e) {
      console.log("Update failed", e);
    }
  }

  // --- HELPER COMPONENT FOR PATH ---
  function LevelNode({ level, desc, minutes, required, isLast }) {
    const isUnlocked = minutes >= required;

    return (
      <View style={styles.nodeWrapper}>
        {/* Left: Avatar/Icon */}
        <View style={[styles.nodeIcon, !isUnlocked && styles.lockedNode]}>
          {isUnlocked ? (
            // UNLOCKED AVATAR (Use cartoonish icons)
            <LinearGradient
              colors={[Colors.premium.gold, "#B8860B"]}
              style={styles.avatarGradient}
            >
              <Ionicons name="person" size={24} color="#fff" />
            </LinearGradient>
          ) : (
            // LOCKED STATE
            <View style={styles.lockedCircle}>
              <Ionicons name="lock-closed" size={20} color="#555" />
            </View>
          )}
        </View>

        {/* Center: Info */}
        <View style={styles.nodeInfo}>
          <Text style={[styles.nodeTitle, !isUnlocked && { color: "#555" }]}>
            {level}
          </Text>
          <Text style={styles.nodeDesc}>
            {isUnlocked ? "Unlocked" : `Unlocks at ${required} mins`}
          </Text>
        </View>

        {/* Right: Status */}
        <View>
          {isUnlocked && (
            <Ionicons
              name="checkmark-circle"
              size={24}
              color={Colors.premium.gold}
            />
          )}
        </View>

        {/* Connecting Line (Don't show for last item) */}
        {!isLast && (
          <View
            style={[
              styles.connectorLine,
              isUnlocked
                ? { backgroundColor: Colors.premium.gold }
                : { backgroundColor: "#333" },
            ]}
          />
        )}
      </View>
    );
  }
}

// Helper component for menu items
function MenuOption({ icon, label }: { icon: any; label: string }) {
  return (
    <TouchableOpacity style={styles.menuRow}>
      <View style={{ flexDirection: "row", alignItems: "center", gap: 15 }}>
        <Ionicons name={icon} size={22} color="#A1A1AA" />
        <Text style={styles.menuText}>{label}</Text>
      </View>
      <Ionicons name="chevron-forward" size={20} color="#333" />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#000" },
  content: { paddingBottom: 120, paddingTop: 60 },

  // HEADER & AVATAR
  header: { alignItems: "center", marginBottom: 40 },
  avatarRing: {
    padding: 4,
    borderRadius: 100,
    shadowColor: Colors.premium.gold,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 20,
    elevation: 20,
  },
  avatarContainer: {
    width: 110,
    height: 110,
    borderRadius: 55,
    backgroundColor: "#111",
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: "#000",
  },
  username: {
    color: "#fff",
    fontSize: 28,
    fontWeight: "800",
    marginTop: 20,
    letterSpacing: 0.5,
  },
  editHint: { color: "rgba(255,255,255,0.4)", fontSize: 12, marginTop: 5 },

  // GOLD POINTS CARD
  pointsCard: {
    marginHorizontal: 20,
    height: 140,
    borderRadius: 30,
    padding: 25,
    marginBottom: 35,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "rgba(255,215,0,0.5)",
  },
  pointsLabel: {
    color: "#4a4008", // Dark Gold
    fontSize: 14,
    fontWeight: "800",
    letterSpacing: 2,
    marginBottom: 5,
  },
  pointsValue: {
    color: "#2a2002",
    fontSize: 42,
    fontWeight: "900",
  },
  pointsSub: {
    color: "#4a4008",
    fontWeight: "600",
    fontSize: 12,
  },
  iconCircle: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: "rgba(255,255,255,0.25)",
    justifyContent: "center",
    alignItems: "center",
  },

  // JOURNEY MAP
  sectionTitle: {
    color: "#fff",
    fontSize: 20,
    fontWeight: "800",
    marginBottom: 20,
    marginLeft: 20,
  },
  mapContainer: {
    marginHorizontal: 20,
    backgroundColor: "rgba(255,255,255,0.05)",
    borderRadius: 25,
    padding: 20,
    marginBottom: 35,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.1)",
  },
  levelRow: {
    flexDirection: "row",
    alignItems: "center",
    height: 60,
  },
  timelineLine: {
    position: "absolute",
    left: 9,
    top: 25,
    bottom: -25, // Connects to next
    width: 2,
    backgroundColor: "rgba(255,255,255,0.1)",
    zIndex: -1,
  },
  dot: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: "#222",
    borderWidth: 2,
    borderColor: "#444",
    marginRight: 15,
    zIndex: 1,
  },
  activeDot: {
    backgroundColor: Colors.premium.gold,
    borderColor: "#fff",
    shadowColor: Colors.premium.gold,
    shadowOpacity: 0.8,
    shadowRadius: 10,
  },
  levelInfo: { flex: 1 },
  levelName: { color: "#666", fontSize: 16, fontWeight: "700" },
  activeLevelName: { color: "#fff", fontSize: 18 },
  levelDesc: { color: "#444", fontSize: 12 },
  activeLevelDesc: { color: Colors.premium.gold, fontSize: 12 },

  // SETTINGS
  menuItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.05)",
    padding: 18,
    borderRadius: 20,
    marginBottom: 10,
    marginHorizontal: 20,
  },
  menuLeft: { flexDirection: "row", alignItems: "center", gap: 15 },
  menuText: { color: "#fff", fontSize: 16, fontWeight: "600" },
  logoutBtn: {
    marginTop: 30,
    alignItems: "center",
    padding: 15,
    borderWidth: 1,
    borderColor: "#FF453A",
    marginHorizontal: 100,
    borderRadius: 30,
  },
  logoutText: { color: "#FF453A", fontWeight: "700", letterSpacing: 1 },

  // ... existing styles ...

  // EDIT NAME STYLES
  editContainer: { flexDirection: "row", alignItems: "center", marginTop: 20 },
  editInput: {
    backgroundColor: "#222",
    color: "#fff",
    fontSize: 22,
    padding: 10,
    borderRadius: 10,
    width: 200,
    textAlign: "center",
    fontWeight: "700",
  },
  saveBtn: { marginLeft: 15 },

  // NEW PATH STYLES
  pathContainer: {
    marginHorizontal: 20,
    marginBottom: 20,
    paddingHorizontal: 10,
  },
  nodeWrapper: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 40, // Space for connector
    position: "relative",
  },
  nodeIcon: {
    width: 60,
    height: 60,
    marginRight: 20,
    justifyContent: "center",
    alignItems: "center",
    zIndex: 10, // Sit on top of line
  },
  avatarGradient: {
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: "#fff",
  },
  lockedNode: {
    opacity: 0.8,
  },
  lockedCircle: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: "#1a1a1a",
    borderWidth: 2,
    borderColor: "#333",
    justifyContent: "center",
    alignItems: "center",
  },
  nodeInfo: { flex: 1 },
  nodeTitle: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "800",
    marginBottom: 4,
  },
  nodeDesc: { color: "#888", fontSize: 12 },

  connectorLine: {
    position: "absolute",
    left: 29, // Center of the 60px circle
    top: 60,
    height: 40, // Height of the gap
    width: 3,
    zIndex: -1,
  },

  helperBadge: {
    flexDirection: "row",
    backgroundColor: "rgba(255,215,0,0.1)",
    marginHorizontal: 20,
    padding: 15,
    borderRadius: 15,
    alignItems: "center",
    marginBottom: 30,
    borderWidth: 1,
    borderColor: "rgba(255,215,0,0.3)",
  },
  helperText: {
    color: "#ccc",
    fontSize: 12,
    marginLeft: 10,
    flex: 1,
  },
});
