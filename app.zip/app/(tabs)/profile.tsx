import { Colors } from "@/constants/theme";
import { Ionicons } from "@expo/vector-icons";
import { BlurView } from "expo-blur";
import { useFocusEffect, useRouter } from "expo-router";
import React, { useCallback, useState } from "react";
import {
  FlatList, // <--- ADDED
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { usePlayer } from "../../app/PlayerContext"; // <--- ADDED (To play songs)
import { supabase } from "../../supabaseConfig";

export default function ProfileScreen() {
  const router = useRouter();
  const [email, setEmail] = useState("Loading...");
  const [isPremium, setIsPremium] = useState(false);

  // RESTORED: Your original stats state
  const [stats, setStats] = useState({ streak: 0, minutes: 0 });
  const [loading, setLoading] = useState(true);

  const [favorites, setFavorites] = useState([]); // <--- NEW STATE
  const { playTrackList } = usePlayer(); // <--- NEW HOOK

  // Fetch Favorites Wrapper
  async function getFavorites() {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from("favorites")
      .select("audios(*)")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false }) // Recent first
      .limit(3); // <--- ONLY TOP 3

    if (data) {
      // Flatten the response (Supabase returns { audios: {...} })
      const songs = data.map((item) => item.audios).filter(Boolean);
      setFavorites(songs);
    }
  }

  // RESTORED: Your exact logic to fetch data
  useFocusEffect(
    useCallback(() => {
      getProfile();
      getFavorites(); // <--- CALL THIS TOO
    }, []),
  );

  async function getProfile() {
    try {
      setLoading(true);
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        router.replace("/auth");
        return;
      }

      setEmail(user.email || "User");

      // Fetch stats & premium status from 'profiles' table
      const { data, error } = await supabase
        .from("profiles")
        .select("is_premium, streak_count, total_minutes")
        .eq("id", user.id)
        .single();

      if (data) {
        setIsPremium(data.is_premium || false);
        setStats({
          streak: data.streak_count || 0,
          minutes: data.total_minutes || 0,
        });
      }
    } catch (error) {
      console.log("Error fetching profile:", error);
    } finally {
      setLoading(false);
    }
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    router.replace("/auth");
  }

  return (
    <View style={styles.container}>
      {/* Premium Background - REMOVED for Video */}
      {/* <LinearGradient
        colors={[Colors.premium.gradientStart, "#000"]}
        style={StyleSheet.absoluteFill}
      /> */}

      <ScrollView contentContainerStyle={styles.content}>
        {/* Profile Header */}
        <View style={styles.profileHeader}>
          <View style={styles.avatarContainer}>
            <Ionicons name="person" size={40} color="#fff" />
          </View>
          <Text style={styles.username}>{email}</Text>

          {/* Dynamic Premium Badge */}
          {isPremium && (
            <View style={styles.badge}>
              <Text style={styles.badgeText}>PREMIUM MEMBER</Text>
            </View>
          )}
        </View>

        {/* Stats Row (CONNECTED TO REAL DATA) */}
        <View style={styles.statsRow}>
          <BlurView intensity={20} tint="dark" style={styles.statCard}>
            <Ionicons
              name="flame"
              size={24}
              color="#FF4500"
              style={{ marginBottom: 5 }}
            />
            <Text style={styles.statNumber}>{stats.streak}</Text>
            <Text style={styles.statLabel}>Day Streak</Text>
          </BlurView>

          <BlurView intensity={20} tint="dark" style={styles.statCard}>
            <Ionicons
              name="time"
              size={24}
              color="#00BFFF"
              style={{ marginBottom: 5 }}
            />
            <Text style={styles.statNumber}>{stats.minutes}</Text>
            <Text style={styles.statLabel}>Minutes Listened</Text>
          </BlurView>
        </View>

        {/* Menu Items */}
        <View style={styles.menuContainer}>
          {/* Favorites Section (Only shows if you have likes) */}
          {favorites.length > 0 && (
            <View style={{ marginBottom: 30 }}>
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom: 15,
                }}
              >
                <Text
                  style={{ color: "#fff", fontSize: 18, fontWeight: "700" }}
                >
                  Liked Vibes ❤️
                </Text>
                <TouchableOpacity
                  onPress={() => router.push("/(tabs)/favorites")}
                >
                  <Text
                    style={{
                      color: Colors.premium.gold,
                      fontSize: 14,
                      fontWeight: "600",
                    }}
                  >
                    See All
                  </Text>
                </TouchableOpacity>
              </View>
              <FlatList
                data={favorites}
                horizontal
                showsHorizontalScrollIndicator={false}
                keyExtractor={(item) => item.id.toString()}
                renderItem={({ item }) => (
                  <TouchableOpacity
                    style={{ marginRight: 15, width: 100 }}
                    onPress={() => {
                      // Convert to Player Format
                      const track = {
                        id: item.id,
                        url: item.audio_url,
                        title: item.title,
                        artist: "Liked Vibe",
                        artwork: item.image_url,
                        duration: item.duration_sec,
                      };
                      playTrackList([track], 0); // Play this song
                      router.push("/player");
                    }}
                  >
                    <Image
                      source={{ uri: item.image_url }}
                      style={{
                        width: 100,
                        height: 100,
                        borderRadius: 15,
                        marginBottom: 8,
                      }}
                    />
                    <Text
                      style={{ color: "#fff", fontSize: 12, fontWeight: "600" }}
                      numberOfLines={1}
                    >
                      {item.title}
                    </Text>
                  </TouchableOpacity>
                )}
              />
            </View>
          )}

          {/* 📥 NEW DOWNLOADS BUTTON */}
          <TouchableOpacity
            onPress={() => router.push("/downloads")}
            style={styles.menuRow}
          >
            <View
              style={{ flexDirection: "row", alignItems: "center", gap: 15 }}
            >
              <Ionicons
                name="cloud-offline-outline"
                size={22}
                color="#4ADE80"
              />
              <Text style={styles.menuText}>Offline Downloads</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#333" />
          </TouchableOpacity>

          <MenuOption icon="settings-outline" label="Account Settings" />

          <TouchableOpacity
            onPress={() => router.push("/paywall")}
            style={styles.menuRow}
          >
            <View
              style={{ flexDirection: "row", alignItems: "center", gap: 15 }}
            >
              <Ionicons name="card-outline" size={22} color="#A1A1AA" />
              <Text style={styles.menuText}>Subscription Plan</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#333" />
          </TouchableOpacity>

          <MenuOption icon="notifications-outline" label="Notifications" />

          <TouchableOpacity onPress={handleLogout} style={styles.logoutButton}>
            <Text style={styles.logoutText}>Log Out</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

// Helper component for menu items
function MenuOption({ icon, label }: { icon: any; label: string }) {
  return (
    <TouchableOpacity style={styles.menuRow}>
      <View style={{ flexDirection: "row", alignItems: "center", gap: 15 }}>
        <Ionicons name={icon} size={22} color="#A1A1AA" />
        <Text style={styles.menuText}>{label}</Text>
      </View>
      <Ionicons name="chevron-forward" size={20} color="#333" />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "transparent" },
  content: { padding: 25, paddingTop: 80 },
  profileHeader: { alignItems: "center", marginBottom: 40 },
  avatarContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: "rgba(255,255,255,0.1)",
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: Colors.premium.gold,
    marginBottom: 15,
  },
  username: { color: "#fff", fontSize: 22, fontWeight: "700", marginBottom: 5 },
  badge: {
    backgroundColor: Colors.premium.gold,
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 8,
    marginTop: 5,
  },
  badgeText: { fontSize: 10, fontWeight: "800", color: "#000" },

  statsRow: { flexDirection: "row", gap: 15, marginBottom: 40 },
  statCard: {
    flex: 1,
    padding: 20,
    borderRadius: 20,
    overflow: "hidden",
    backgroundColor: "rgba(255,255,255,0.05)",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.1)",
  },
  statNumber: {
    fontSize: 28,
    fontWeight: "800",
    color: "#fff",
    marginBottom: 2,
  },
  statLabel: {
    fontSize: 12,
    color: "#888",
    textTransform: "uppercase",
    letterSpacing: 1,
  },

  menuContainer: { gap: 10 },
  menuRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 18, // Changed to padding all around
    backgroundColor: "rgba(0,0,0,0.4)", // Dark background added
    borderRadius: 16, // Rounded corners
    marginBottom: 10, // Spacing between items
    // Removed borderBottom logic
  },
  menuText: { color: "#fff", fontSize: 16 },
  logoutButton: {
    marginTop: 30,
    alignItems: "center",
    padding: 15,
    backgroundColor: "rgba(255, 59, 48, 0.1)",
    borderRadius: 12,
  },
  logoutText: { color: "#FF3B30", fontWeight: "700" },
});
