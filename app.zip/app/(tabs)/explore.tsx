import { Colors } from "@/constants/theme";
import { Ionicons } from "@expo/vector-icons";
import { BlurView } from "expo-blur";
import { LinearGradient } from "expo-linear-gradient";
import { useFocusEffect, useRouter } from "expo-router";
import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Dimensions,
  FlatList,
  Keyboard,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import Animated, { FadeInRight, FadeInUp } from "react-native-reanimated";
import { SafeAreaView } from "react-native-safe-area-context";
import { supabase } from "../../supabaseConfig";
import { usePlayer } from "../PlayerContext";

const { width } = Dimensions.get("window");

const CATEGORIES = [
  "Life Motivation",
  "Business & Work",
  "Health & Discipline",
  "Relationship",
  "Spiritual",
];

export default function ExploreScreen() {
  const router = useRouter();
  const { playTrackList, currentTrack } = usePlayer();

  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isPremium, setIsPremium] = useState(false);

  // 1. Check Premium Status
  useFocusEffect(
    useCallback(() => {
      checkUserStatus();
    }, []),
  );

  async function checkUserStatus() {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (user) {
      const { data } = await supabase
        .from("profiles")
        .select("is_premium")
        .eq("id", user.id)
        .single();
      if (data) setIsPremium(data.is_premium);
    }
  }

  // 2. Debounced Search Logic
  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      if (query.length > 0) {
        performSearch();
      } else {
        setResults([]);
      }
    }, 500);

    return () => clearTimeout(delayDebounceFn);
  }, [query]);

  async function performSearch() {
    setLoading(true);
    try {
      // STEP 1: Find IDs of categories that match the query (e.g., "Gym" -> ID 123)
      const { data: catData } = await supabase
        .from("categories")
        .select("id")
        .ilike("name", `%${query}%`);

      const catIds = catData ? catData.map((c) => c.id) : [];

      // STEP 2: Find Audios that match the Title OR belong to those Category IDs
      let audioQuery = supabase.from("audios").select("*");

      if (catIds.length > 0) {
        // If we found matching categories, include them in the search
        // Syntax: title contains query OR category_id is in the found list
        audioQuery = audioQuery.or(
          `title.ilike.%${query}%,category_id.in.(${catIds.join(",")})`,
        );
      } else {
        // If no categories matched, just search the Title
        audioQuery = audioQuery.ilike("title", `%${query}%`);
      }

      const { data, error } = await audioQuery.limit(20);

      if (!error) {
        setResults(data || []);
      } else {
        console.log("Search Error:", error);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  // 3. Play & Lock Logic
  const handlePlay = (track) => {
    Keyboard.dismiss();

    if (track.is_locked && !isPremium) {
      Alert.alert(
        "Locked Track 🔒",
        "Upgrade to Premium to access this result.",
        [
          { text: "Cancel", style: "cancel" },
          { text: "Upgrade", onPress: () => router.push("/paywall") },
        ],
      );
      return;
    }

    const formattedTrack = {
      id: track.id,
      url: track.audio_url,
      title: track.title,
      artist: "Motivation Search",
      artwork: track.image_url,
      duration: track.duration_sec,
      is_locked: track.is_locked,
    };

    playTrackList([formattedTrack], 0);
    router.push("/player");
  };

  // --- RENDER HELPERS ---

  // A. The "Beautiful" Dashboard (Visible when NOT searching)
  const renderDashboard = () => (
    <ScrollView
      contentContainerStyle={{ paddingBottom: 100 }}
      showsVerticalScrollIndicator={false}
    >
      {/* Featured Section */}
      <Text style={styles.sectionTitle}>Trending Now</Text>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={{ marginBottom: 30 }}
      >
        {[1, 2, 3].map((item, index) => (
          <Animated.View
            key={item}
            entering={FadeInRight.delay(index * 200).springify()}
          >
            <TouchableOpacity style={styles.featuredCard}>
              <LinearGradient
                colors={["#4c669f", "#3b5998", "#192f6a"]}
                style={StyleSheet.absoluteFill}
              />
              <Text style={styles.featuredText}>Featured Mix {item}</Text>
              <Ionicons
                name="play-circle"
                size={40}
                color="rgba(255,255,255,0.8)"
              />
            </TouchableOpacity>
          </Animated.View>
        ))}
      </ScrollView>

      {/* Categories Grid (Now Clickable!) */}
      <Text style={styles.sectionTitle}>Browse All</Text>
      <View style={styles.grid}>
        {CATEGORIES.map((cat, index) => (
          <Animated.View
            key={cat}
            entering={FadeInUp.delay(index * 100).springify()}
            style={styles.categoryWrapper}
          >
            <TouchableOpacity
              activeOpacity={0.7}
              onPress={() => setQuery(cat)} // <--- CLICK TO SEARCH
            >
              <BlurView intensity={20} tint="dark" style={styles.categoryBox}>
                <Text style={styles.categoryText}>{cat}</Text>
              </BlurView>
            </TouchableOpacity>
          </Animated.View>
        ))}
      </View>
    </ScrollView>
  );

  // B. The Search Results List (Visible when searching)
  const renderSearchResults = () => (
    <View style={{ flex: 1 }}>
      {loading ? (
        <ActivityIndicator
          size="large"
          color={Colors.premium.gold}
          style={{ marginTop: 50 }}
        />
      ) : (
        <FlatList
          data={results}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ paddingBottom: 100 }}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <Ionicons name="search" size={50} color="#333" />
              <Text style={styles.emptyText}>
                No vibes found matching "{query}"
              </Text>
            </View>
          }
          renderItem={({ item, index }) => {
            const isActive = currentTrack && currentTrack.id === item.id;
            return (
              <Animated.View entering={FadeInUp.delay(index * 50).springify()}>
                <TouchableOpacity onPress={() => handlePlay(item)}>
                  <BlurView
                    intensity={15}
                    tint="light"
                    style={[styles.resultRow, isActive && styles.activeRow]}
                  >
                    <View style={styles.resultIcon}>
                      <Ionicons
                        name="musical-note"
                        size={20}
                        color={isActive ? "#000" : "#fff"}
                      />
                    </View>
                    <View style={styles.resultInfo}>
                      <Text
                        style={[
                          styles.resultTitle,
                          isActive && { color: Colors.premium.gold },
                        ]}
                      >
                        {item.title}
                      </Text>
                      <Text style={styles.resultSub}>
                        {Math.floor(item.duration_sec / 60)}:
                        {(item.duration_sec % 60).toString().padStart(2, "0")} •
                        Search Result
                      </Text>
                    </View>
                    {item.is_locked && !isPremium ? (
                      <Ionicons name="lock-closed" size={18} color="#FF4500" />
                    ) : (
                      <Ionicons
                        name="play-circle"
                        size={28}
                        color={isActive ? Colors.premium.gold : "#444"}
                      />
                    )}
                  </BlurView>
                </TouchableOpacity>
              </Animated.View>
            );
          }}
        />
      )}
    </View>
  );

  // --- MAIN RENDER ---
  return (
    <View style={styles.container}>
      {/* Gradient DELETED for video */}

      <SafeAreaView style={{ flex: 1, paddingHorizontal: 20 }}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Discover</Text>
          <Text style={styles.headerSubtitle}>Find your perfect rhythm</Text>
        </View>

        {/* Search Bar (Persistent) */}
        <BlurView intensity={25} tint="dark" style={styles.searchBar}>
          <Ionicons name="search" size={20} color="#999" />
          <TextInput
            style={styles.searchInput}
            placeholder="Search playlists, artists..."
            placeholderTextColor="#666"
            value={query}
            onChangeText={setQuery}
            autoCorrect={false}
          />
          {query.length > 0 && (
            <TouchableOpacity onPress={() => setQuery("")}>
              <Ionicons name="close-circle" size={20} color="#666" />
            </TouchableOpacity>
          )}
        </BlurView>

        {/* Conditional Content */}
        {query.length > 0 ? renderSearchResults() : renderDashboard()}
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "transparent" }, // <--- CHANGED #000 to transparent

  header: { marginTop: 10, marginBottom: 20 },
  headerTitle: { fontSize: 34, fontWeight: "800", color: "#fff" },
  headerSubtitle: { fontSize: 16, color: "#A1A1AA", marginTop: 5 },

  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.05)",
    padding: 15,
    borderRadius: 15,
    marginBottom: 20,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.1)",
  },
  searchInput: { marginLeft: 10, color: "#fff", flex: 1, fontSize: 16 },

  // Dashboard Styles
  sectionTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: "#fff",
    marginBottom: 15,
    marginTop: 10,
  },
  featuredCard: {
    width: 250,
    height: 150,
    borderRadius: 20,
    marginRight: 15,
    overflow: "hidden",
    justifyContent: "flex-end",
    padding: 15,
    backgroundColor: "#333",
  },
  featuredText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
    marginBottom: 5,
  },

  grid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  categoryWrapper: { width: "48%" }, // Helper to maintain grid width with padding/gap
  categoryBox: {
    height: 80,
    borderRadius: 15,
    overflow: "hidden",
    backgroundColor: "rgba(255,255,255,0.05)",
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.1)",
  },
  categoryText: { color: "#fff", fontWeight: "600", fontSize: 16 },

  // Result List Styles
  resultRow: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(0,0,0,0.5)", // Darker for visibility
    marginBottom: 10,
    padding: 12,
    borderRadius: 12,
    overflow: "hidden",
  },
  activeRow: {
    backgroundColor: "rgba(212, 175, 55, 0.15)",
    borderColor: Colors.premium.gold,
    borderWidth: 1,
  },
  resultIcon: {
    width: 40,
    height: 40,
    borderRadius: 8,
    backgroundColor: "rgba(255,255,255,0.1)",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 15,
  },
  resultInfo: { flex: 1 },
  resultTitle: { color: "#fff", fontSize: 16, fontWeight: "600" },
  resultSub: { color: "#666", fontSize: 12, marginTop: 2 },
  emptyState: { alignItems: "center", marginTop: 50, opacity: 0.5 },
  emptyText: { color: "#fff", marginTop: 10, fontSize: 16 },
});
