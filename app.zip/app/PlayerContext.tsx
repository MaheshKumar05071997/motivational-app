import { Audio } from "expo-av";
import { useRouter } from "expo-router";
import React, {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import { AppState } from "react-native"; // <--- ADD THIS
import { supabase } from "../supabaseConfig";

const PlayerContext = createContext(null);

export function PlayerProvider({ children }) {
  const router = useRouter(); // <--- NEW
  const soundRef = useRef(null); // <--- NEW (To track sound even during logout)
  const currentTrackRef = useRef(null); // <--- Fix for stats
  const [sound, setSound] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrack, setCurrentTrack] = useState(null);
  const [queue, setQueue] = useState([]); // List of songs
  const [currentIndex, setCurrentIndex] = useState(0);
  const [position, setPosition] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isBuffering, setIsBuffering] = useState(false);

  const [isPremium, setIsPremium] = useState(false);

  // Check Premium Status & Listen for Login Changes
  useEffect(() => {
    // A. Enable Background Audio for the App
    async function configureAudio() {
      try {
        await Audio.setAudioModeAsync({
          staysActiveInBackground: true, // Critical for Premium
          playsInSilentModeIOS: true,
          shouldDuckAndroid: true,
          playThroughEarpieceAndroid: false,
        });
      } catch (e) {
        console.log("Audio Config Error:", e);
      }
    }
    configureAudio();

    checkPremium();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event) => {
      checkPremium();

      // FIX 2: STOP MUSIC ON LOGOUT
      if (event === "SIGNED_OUT") {
        if (soundRef.current) {
          await soundRef.current.unloadAsync();
        }
        setSound(null);
        soundRef.current = null;
        setCurrentTrack(null);
        setIsPlaying(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  async function checkPremium() {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (user) {
      const { data } = await supabase
        .from("profiles")
        .select("is_premium")
        .eq("id", user.id)
        .single();
      // If data exists, set premium. If not, false.
      setIsPremium(data?.is_premium || false);
    } else {
      setIsPremium(false); // Ensure we reset to false if logged out
    }
  }

  // --- AUDIO LOGIC ---
  async function loadTrack(track, shouldPlay = true) {
    try {
      if (sound) await sound.unloadAsync();

      const { sound: newSound, status } = await Audio.Sound.createAsync(
        { uri: track.url },
        { shouldPlay: shouldPlay },
        onPlaybackStatusUpdate,
      );

      setSound(newSound);
      soundRef.current = newSound; // <--- KEEP REF IN SYNC
      currentTrackRef.current = track; // <--- UPDATE REF HERE
      setCurrentTrack(track);
      setIsPlaying(shouldPlay);
    } catch (error) {
      console.log("Error loading track:", error);
    }
  }

  const onPlaybackStatusUpdate = (status) => {
    if (status.isLoaded) {
      setDuration(status.durationMillis || 0);
      setPosition(status.positionMillis || 0);
      setIsBuffering(status.isBuffering);
      setIsPlaying(status.isPlaying);

      if (status.didJustFinish) {
        // Use REF to get the actual finished track, not the stale one
        if (currentTrackRef.current) {
          updateStats(currentTrackRef.current.duration);
        }
        playNext();
      }
    }
  };

  async function playTrackList(tracks, index) {
    setQueue(tracks);
    setCurrentIndex(index);
    await loadTrack(tracks[index]);
  }

  async function togglePlayPause() {
    if (!sound) return;
    if (isPlaying) await sound.pauseAsync();
    else await sound.playAsync();
  }

  async function playNext() {
    if (currentIndex < queue.length - 1) {
      const nextIndex = currentIndex + 1;
      const nextTrack = queue[nextIndex];

      // SECURITY CHECK: If locked and user not premium -> POP UP PAYWALL
      if (nextTrack.is_locked && !isPremium) {
        router.push("/paywall"); // <--- FIX 1: Open Paywall
        return;
      }

      setCurrentIndex(nextIndex);
      await loadTrack(nextTrack);
    }
  }

  async function playPrev() {
    if (currentIndex > 0) {
      const prevIndex = currentIndex - 1;
      const prevTrack = queue[prevIndex];

      // SECURITY CHECK: If previous song is locked and user is NOT premium -> POP UP PAYWALL
      if (prevTrack.is_locked && !isPremium) {
        router.push("/paywall");
        return;
      }

      setCurrentIndex(prevIndex);
      await loadTrack(prevTrack);
    }
  }

  async function seekTo(millis) {
    if (sound) await sound.setPositionAsync(millis);
  }

  // --- GAMIFICATION STATS ---
  async function updateStats(seconds) {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    // Quick update logic
    const today = new Date().toISOString().split("T")[0];
    const { data: profile } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", user.id)
      .single();

    if (profile) {
      let newStreak = profile.streak_count || 0;

      // Simple streak logic: if last listened date is NOT today, add 1
      if (profile.last_listened_date !== today) {
        newStreak += 1;
      }

      await supabase
        .from("profiles")
        .update({
          streak_count: newStreak,
          last_listened_date: today,
          total_minutes: (profile.total_minutes || 0) + Math.ceil(seconds / 60),
        })
        .eq("id", user.id);
    }
  }

  // --- BACKGROUND PLAYBACK CONTROL 👮‍♂️ ---
  useEffect(() => {
    const handleAppStateChange = (nextAppState) => {
      // If user goes to Background (Lock Screen/Home) AND is NOT Premium -> PAUSE
      if (nextAppState === "background" && !isPremium && isPlaying && sound) {
        sound.pauseAsync();
        setIsPlaying(false);
      }
    };

    const subscription = AppState.addEventListener(
      "change",
      handleAppStateChange,
    );

    return () => {
      subscription.remove();
    };
  }, [isPremium, isPlaying, sound]);

  useEffect(() => {
    return () => {
      if (sound) sound.unloadAsync();
    };
  }, [sound]);

  return (
    <PlayerContext.Provider
      value={{
        isPremium, // <--- ADD THIS LINE (Fixes the bug)
        currentTrack,
        isPlaying,
        position,
        duration,
        isBuffering,
        playTrackList,
        togglePlayPause,
        playNext,
        playPrev,
        seekTo,
        queue, // <--- ADD
        currentIndex, // <--- ADD
        fullPlayerVisible: !!currentTrack,
      }}
    >
      {children}
    </PlayerContext.Provider>
  );
}

export const usePlayer = () => useContext(PlayerContext);
// Add this at the VERY END of the file to fix the "Missing default export" warning
export default function PlayerContextRoute() {
  return null;
}
