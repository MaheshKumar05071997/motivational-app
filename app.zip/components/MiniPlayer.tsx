import { Colors } from "@/constants/theme";
import { Ionicons } from "@expo/vector-icons";
import { BlurView } from "expo-blur";
import { useRouter } from "expo-router";
import React from "react";
import {
  ActivityIndicator,
  Dimensions,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { usePlayer } from "../app/PlayerContext";

const { width } = Dimensions.get("window");

export default function MiniPlayer() {
  const router = useRouter();
  const {
    currentTrack,
    isPlaying,
    togglePlayPause,
    position,
    duration,
    isBuffering,
    playNext,
    playPrev, // <--- ADD THIS HERE
    queue, // <--- Add this
    currentIndex, // <--- Add this
  } = usePlayer();

  if (!currentTrack) return null;

  // Calculate progress percentage
  const progress = duration > 0 ? (position / duration) * 100 : 0;

  return (
    <TouchableOpacity
      activeOpacity={0.9}
      onPress={() => router.push("/player")}
      style={styles.floatingContainer}
    >
      <BlurView intensity={25} tint="dark" style={styles.glassContainer}>
        {/* 1. Content Row */}
        <View style={styles.contentRow}>
          {/* Album Art Thumbnail */}
          <View style={styles.artContainer}>
            {currentTrack.artwork ? (
              <Image
                source={{ uri: currentTrack.artwork }}
                style={styles.tinyArt}
              />
            ) : (
              <View style={styles.placeholderArt}>
                <Ionicons name="musical-note" size={16} color="#000" />
              </View>
            )}
          </View>

          {/* Title & Artist */}
          <View style={styles.textContainer}>
            <Text style={styles.title} numberOfLines={1}>
              {currentTrack.title}
            </Text>
            <Text style={styles.artist} numberOfLines={1}>
              {currentTrack.artist || "Motivation App"}
            </Text>
          </View>

          {/* Controls */}
          {/* Controls */}
          <View style={styles.controls}>
            {/* Prev Button (Disabled if first song) */}
            <TouchableOpacity
              onPress={(e) => {
                e.stopPropagation();
                playPrev();
              }}
              disabled={currentIndex === 0}
            >
              <Ionicons
                name="play-skip-back"
                size={24}
                color={currentIndex === 0 ? "rgba(255,255,255,0.2)" : "#fff"}
              />
            </TouchableOpacity>

            {/* Play/Pause Button */}
            <TouchableOpacity
              onPress={(e) => {
                e.stopPropagation();
                togglePlayPause();
              }}
              style={styles.playButton}
            >
              {isBuffering ? (
                <ActivityIndicator color="#000" size="small" />
              ) : (
                <Ionicons
                  name={isPlaying ? "pause" : "play"}
                  size={20}
                  color="#000"
                  style={{ marginLeft: isPlaying ? 0 : 2 }}
                />
              )}
            </TouchableOpacity>

            {/* Next Button (Disabled if last song) */}
            <TouchableOpacity
              onPress={(e) => {
                e.stopPropagation();
                playNext();
              }}
              disabled={!queue || currentIndex >= queue.length - 1}
            >
              <Ionicons
                name="play-skip-forward"
                size={24}
                color={
                  !queue || currentIndex >= queue.length - 1
                    ? "rgba(255,255,255,0.2)"
                    : "#fff"
                }
                style={{ opacity: 0.8 }}
              />
            </TouchableOpacity>
          </View>
        </View>

        {/* 2. Golden Progress Line (Bottom) */}
        <View style={styles.progressBarBackground}>
          <View style={[styles.progressBarFill, { width: `${progress}%` }]} />
        </View>
      </BlurView>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  floatingContainer: {
    position: "absolute",
    bottom: 105, // Floats above the tab bar
    left: 15,
    right: 15,
    borderRadius: 16,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 10,
  },
  glassContainer: {
    backgroundColor: "rgba(30, 30, 30, 0.6)", // Semi-transparent dark
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.1)",
  },
  contentRow: {
    flexDirection: "row",
    alignItems: "center",
    padding: 12,
  },
  artContainer: {
    marginRight: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  tinyArt: {
    width: 44,
    height: 44,
    borderRadius: 8,
    backgroundColor: "#333",
  },
  placeholderArt: {
    width: 44,
    height: 44,
    borderRadius: 8,
    backgroundColor: Colors.premium.gold,
    justifyContent: "center",
    alignItems: "center",
  },
  textContainer: {
    flex: 1,
    justifyContent: "center",
    marginRight: 10,
  },
  title: {
    color: "#fff",
    fontSize: 14,
    fontWeight: "700",
    marginBottom: 2,
  },
  artist: {
    color: "rgba(255,255,255,0.6)",
    fontSize: 11,
    fontWeight: "500",
  },
  controls: {
    flexDirection: "row",
    alignItems: "center",
    gap: 15,
  },
  playButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.premium.gold,
    justifyContent: "center",
    alignItems: "center",
  },
  progressBarBackground: {
    height: 2,
    backgroundColor: "rgba(255,255,255,0.1)",
    width: "100%",
  },
  progressBarFill: {
    height: "100%",
    backgroundColor: Colors.premium.gold,
  },
});
